//
//  CustomModel.h
//  testApp
//
//  Created by 刘恋 on 2018/8/24.
//  Copyright © 2018年 刘恋. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomModel : NSObject


@property(nonatomic,copy)NSString *nickName;

@property(nonatomic,copy)NSString *content;

@end
