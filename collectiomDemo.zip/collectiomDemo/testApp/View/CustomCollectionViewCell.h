//
//  CustomCollectionViewCell.h
//  testApp
//
//  Created by 刘恋 on 2018/8/24.
//  Copyright © 2018年 刘恋. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomCollectModel.h"

@interface CustomCollectionViewCell : UICollectionViewCell


@property(nonatomic,strong)CustomCollectModel *customModel;


@end
