//
//  CustomTableViewCell.h
//  testApp
//
//  Created by 刘恋 on 2018/8/24.
//  Copyright © 2018年 刘恋. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomModel.h"

@interface CustomTableViewCell : UITableViewCell

@property(nonatomic,strong) CustomModel *custModel;

@end
